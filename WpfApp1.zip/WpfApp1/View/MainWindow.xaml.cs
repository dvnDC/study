﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using WpfApp1.Model;

using IOPath = System.IO.Path;
using System.Globalization;

namespace WpfApp1.View
{
    public partial class MainWindow : Window
    {
        private FileExplorer _fileExplorer;

        public MainWindow()
        {
            InitializeComponent();
            var fileExplorerViewModel = new FileExplorer(); // Tworzenie instancji ViewModel
            //DataContext = fileExplorerViewModel; // Przypisanie ViewModel do DataContext okna
            _fileExplorer = new FileExplorer(); // Inicjalizacja _fileExplorer i przypisanie go do DataContext
            DataContext = _fileExplorer;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var fileExplorer = new FileExplorer();
            // Tutaj możesz dodać logikę otwierania domyślnego katalogu lub pokazywania dialogu wyboru folderu

            var dlg = new FolderBrowserDialog() { Description = "Select directory to open" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var path = dlg.SelectedPath;
                fileExplorer.OpenRoot(path);
            }

            DataContext = fileExplorer;
        }

        private void Window_Loaded2(object sender, RoutedEventArgs e)
        {
            var dlg = new FolderBrowserDialog() { Description = "Select directory to open" };
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                var path = dlg.SelectedPath;
                var fileExplorer = new FileExplorer();
                fileExplorer.OpenRoot(path);
                DataContext = fileExplorer;
            }
        }
        private void OnPolishLanguageSelected(object sender, MouseButtonEventArgs e)
        {
            _fileExplorer.ChangeLanguage("pl-PL");
            //ChangeCulture(new CultureInfo("pl-PL"));
        }

        private void OnEnglishLanguageSelected(object sender, MouseButtonEventArgs e)
        {
            _fileExplorer.ChangeLanguage("en-US");
            //ChangeCulture(new CultureInfo("en-US"));
        }

        private void ChangeCulture(CultureInfo culture)
        {
            _fileExplorer.ChangeCulture(culture.Name);
            // Refresh UI elements that depend on resources
            RefreshResources();
        }

        private void RefreshResources()
        {
            // Implement logic to refresh UI elements that depend on localized resources
        }


    }
}